import 'package:flutter/material.dart';
import 'package:service_app/widgets/drawer.dart';

import '../widgets/bottomNavigationBar.dart';
import 'booking_page.dart';
import 'customerCare_page.dart';
import 'home_Page.dart';
import 'notification_page.dart';

class BookingPage extends StatefulWidget {
  const BookingPage({super.key});

  @override
  State<BookingPage> createState() => _BookingPageState();
}

class _BookingPageState extends State<BookingPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: NavigationBars(),
      body: BookingsPage(),
    );
  }
}

class BookingsPage extends StatefulWidget {
  @override
  _BookingsPageState createState() => _BookingsPageState();
}

class _BookingsPageState extends State<BookingsPage>
    with SingleTickerProviderStateMixin {
  TabController? _tabController;

  final List<BookingItem> upcomingBookings = [
    BookingItem(
      title: 'AC Regular Service',
      referenceCode: '#ABC123',
      status: 'Confirmed',
      statusColor: Colors.greenAccent,
      schedule: '10:29-10:29 AM, 26 Jun',
      serviceProvider: 'WestingHouse',
      iconPath: 'assets/logo/air-conditioner.png',
      color: Colors.orangeAccent,
    ),
    BookingItem(
      title: 'Beard Trim',
      referenceCode: '#XYZ789',
      status: 'Pending',
      statusColor: Colors.orange,
      schedule: '10:29-10:29 AM, 28 Jun',
      serviceProvider: 'WestingHouse',
      iconPath: 'assets/logo/scissor-and-comb.png',
      color: Colors.purpleAccent,
    ),
  ];

  final List<BookingItem> historyBookings = [
    BookingItem(
      title: 'Exterior Painting',
      referenceCode: '#JKM637',
      status: 'Complete',
      statusColor: Colors.purple,
      schedule: '8:00-9:00 AM, Dec 9',
      serviceProvider: 'Westinghouse',
      iconPath: 'assets/logo/paint-roller.png',
      color: Colors.greenAccent,
    ),
    BookingItem(
      title: 'Office Shifting',
      referenceCode: '#XYZ789',
      status: 'Complete',
      statusColor: Colors.purple,
      schedule: '8:00-9:00 AM, Dec 9',
      serviceProvider: 'Westinghouse',
      iconPath: 'assets/logo/van.png',
      color: Colors.pinkAccent,
    ),
  ];

  final List<BookingItem> draftBookings = [
    BookingItem(
      title: 'Manicure',
      referenceCode: '#PKO295',
      status: 'Draft',
      statusColor: Colors.orangeAccent,
      schedule: '8:00-9:00 AM, Dec 9',
      serviceProvider: 'Westinghouse',
      iconPath: 'assets/logo/hair-dryer.png',
      color: Colors.purpleAccent,
    ),
    BookingItem(
      title: 'AC Regular Service',
      referenceCode: '#MNL3512',
      status: 'Draft',
      statusColor: Colors.orangeAccent,
      schedule: '8:00-9:00 AM, Dec 9',
      serviceProvider: 'Westinghouse',
      iconPath: 'assets/logo/air-conditioner.png',
      color: Colors.lightBlueAccent,
    ),
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          centerTitle: true,
          automaticallyImplyLeading: false,
          title: Text(
            'Bookings',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
          ),
          flexibleSpace: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Color(0xFF2AD2EF), Color(0xFFB9D9F0)],
              ),
            ),
          ),
          titleSpacing: Checkbox.width,
          bottom: TabBar(
            unselectedLabelColor: Colors.black,
            labelColor: Colors.white,
            indicatorSize: TabBarIndicatorSize.tab,
            indicator: BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFFB9D9F0), Color(0xFF2AD2EF)],
              ),
              borderRadius: BorderRadius.circular(50),
              border: Border.all(color: Colors.white),
            ),
            controller: _tabController,
            tabs: [
              Tab(text: 'Upcoming'),
              Tab(text: 'History'),
              Tab(text: 'Draft'),
            ],
          ),
        ),
        body: Stack(
          children: [
            Positioned.fill(
              child: Image.asset(
                'assets/bg.jpg', // Your background image
                fit: BoxFit.cover,
              ),
            ),
            TabBarView(
              controller: _tabController,
              children: [
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: ListView.builder(
                    itemCount: upcomingBookings.length,
                    itemBuilder: (context, index) {
                      return UpComingCard(upcoming: upcomingBookings[index]);
                    },
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: ListView.builder(
                    itemCount: historyBookings.length,
                    itemBuilder: (context, index) {
                      return HistoryCard(history: historyBookings[index]);
                    },
                  ),
                ), // Placeholder for History Tab
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: ListView.builder(
                    itemCount: draftBookings.length,
                    itemBuilder: (context, index) {
                      return DraftCard(draft: draftBookings[index]);
                    },
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class BookingItem {
  final String title;
  final String referenceCode;
  final String status;
  final Color statusColor;
  final String schedule;
  final String serviceProvider;
  final String iconPath; // Updated to String path
  final Color color;

  BookingItem({
    required this.title,
    required this.referenceCode,
    required this.status,
    required this.statusColor,
    required this.schedule,
    required this.serviceProvider,
    required this.iconPath, // Updated to String path
    required this.color,
  });
}

class UpComingCard extends StatelessWidget {
  final BookingItem upcoming;

  UpComingCard({required this.upcoming});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        border: Border.all(color: Colors.white),
        borderRadius: BorderRadius.circular(10),
        color: Colors.white.withOpacity(0.4),
      ),
      margin: EdgeInsets.symmetric(vertical: 8),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 25,
                  backgroundColor: upcoming.color,
                  child: Image.asset(
                    upcoming.iconPath, // Load image asset
                    width: 30,
                    height: 30,
                  ),
                ),
                SizedBox(width: 16),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      upcoming.title,
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      'Reference Code: ${upcoming.referenceCode}',
                      style: TextStyle(
                        color: Colors.grey,
                      ),
                    ),
                  ],
                ),
              ],
            ),
            SizedBox(height: 8),
            Text(
              'Status',
              style: TextStyle(color: Colors.grey),
            ),
            Text(
              upcoming.status,
              style: TextStyle(
                color: upcoming.statusColor,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 8),
            Row(
              children: [
                Icon(Icons.calendar_today, color: Colors.grey),
                SizedBox(width: 8),
                Text(upcoming.schedule),
              ],
            ),
            SizedBox(height: 8),
            Row(
              children: [
                Icon(Icons.business, color: Colors.grey),
                SizedBox(width: 8),
                Text(upcoming.serviceProvider),
                Spacer(),
                ElevatedButton.icon(
                  onPressed: () {
                    // Handle call button press
                  },
                  icon: Icon(Icons.call),
                  label: Text('Call'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class HistoryCard extends StatelessWidget {
  final BookingItem history;

  HistoryCard({required this.history});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        border: Border.all(color: Colors.white),
        borderRadius: BorderRadius.circular(10),
        color: Colors.white.withOpacity(0.4),
      ),
      margin: EdgeInsets.symmetric(vertical: 8),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 25,
                  backgroundColor: history.color,
                  child: Image.asset(
                    history.iconPath, // Load image asset
                    width: 30,
                    height: 30,
                  ),
                ),
                SizedBox(width: 16),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      history.title,
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      'Reference Code: ${history.referenceCode}',
                      style: TextStyle(
                        color: Colors.grey,
                      ),
                    ),
                  ],
                ),
              ],
            ),
            SizedBox(height: 8),
            Text(
              'Status',
              style: TextStyle(color: Colors.grey),
            ),
            Text(
              history.status,
              style: TextStyle(
                color: history.statusColor,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 8),
            Row(
              children: [
                Icon(Icons.calendar_today, color: Colors.grey),
                SizedBox(width: 8),
                Text(history.schedule),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class DraftCard extends StatelessWidget {
  final BookingItem draft;

  DraftCard({required this.draft});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        border: Border.all(color: Colors.white),
        borderRadius: BorderRadius.circular(10),
        color: Colors.white.withOpacity(0.4),
      ),
      margin: EdgeInsets.symmetric(vertical: 8),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 25,
                  backgroundColor: draft.color,
                  child: Image.asset(
                    draft.iconPath, // Load image asset
                    width: 30,
                    height: 30,
                  ),
                ),
                SizedBox(width: 16),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      draft.title,
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      'Reference Code: ${draft.referenceCode}',
                      style: TextStyle(
                        color: Colors.grey,
                      ),
                    ),
                  ],
                ),
              ],
            ),
            SizedBox(height: 8),
            Text(
              'Status',
              style: TextStyle(color: Colors.grey),
            ),
            Text(
              draft.status,
              style: TextStyle(
                color: draft.statusColor,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 8),
            Row(
              children: [
                Icon(Icons.calendar_today, color: Colors.grey),
                SizedBox(width: 8),
                Text(draft.schedule),
              ],
            ),
            SizedBox(height: 8),
            Row(
              children: [
                Icon(Icons.business, color: Colors.grey),
                SizedBox(width: 8),
                Text(draft.serviceProvider),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
