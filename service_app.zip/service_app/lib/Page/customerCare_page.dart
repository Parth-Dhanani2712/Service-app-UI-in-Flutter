import 'package:flutter/material.dart';
import '../widgets/bottomNavigationBar.dart';

class CustomercarePage extends StatefulWidget {
  const CustomercarePage({super.key});

  @override
  State<CustomercarePage> createState() => _CustomercarePageState();
}

class _CustomercarePageState extends State<CustomercarePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        automaticallyImplyLeading: false,
        title: Text(
          "Support",
          style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold),
        ),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFF2AD2EF), Color(0xFFB9D9F0)],
            ),
          ),
        ),
      ),
      bottomNavigationBar: NavigationBars(),
      body: SupportPage(),
    );
  }
}

class SupportPage extends StatelessWidget {
  final List<SupportOption> supportOptions = [
    SupportOption(
      title: 'Live Chat',
      subtitle: 'Chat time 9am - 9pm',
      icon: Icons.chat,
      color: Colors.orangeAccent,
    ),
    SupportOption(
      title: 'Phone Call',
      subtitle: 'Calling hour 9am - 9pm',
      icon: Icons.phone_outlined,
      color: Colors.purpleAccent,
    ),
    SupportOption(
      title: 'WhatsApp Call',
      subtitle: 'Calling hour 9am - 9pm',
      icon: Icons.call,
      color: Colors.lightGreen,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Positioned.fill(
          child: Image.asset(
            'assets/bg.jpg', // Path to your background image
            fit: BoxFit.cover,
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric( vertical: 5.0, horizontal: 10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 15),
              Expanded(
                child: ListView.builder(
                  itemCount: supportOptions.length,
                  itemBuilder: (context, index) {
                    return SupportCard(option: supportOptions[index]);
                  },
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class SupportOption {
  final String title;
  final String subtitle;
  final IconData icon;
  final Color color;

  SupportOption({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.color,
  });
}

class SupportCard extends StatelessWidget {
  final SupportOption option;

  SupportCard({required this.option});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric( vertical:  8.0),
      child: Container(
        decoration: BoxDecoration(
          border: Border.all(color: Colors.white),
          borderRadius: BorderRadius.circular(10),
          color: Colors.white.withOpacity(0.4),
        ),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            children: [
              CircleAvatar(
                radius: 25,
                backgroundColor: option.color,
                child: Icon(
                  option.icon,
                  size: 30,
                  color: Colors.white,
                ),
              ),
              SizedBox(width: 16),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    option.title,
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  ),
                  SizedBox(height: 4),
                  Text(
                    option.subtitle,
                    style: TextStyle(
                      color: Colors.black,
                    ),
                  ),
                ],
              ),
              SizedBox(height: 5,)
            ],
          ),
        ),
      ),
    );
  }
}
