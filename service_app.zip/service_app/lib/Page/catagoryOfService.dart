import 'package:flutter/material.dart';

class CatagoryOfService extends StatefulWidget {
  const CatagoryOfService({Key? key}) : super(key: key);

  @override
  State<CatagoryOfService> createState() => _CatagoryOfServiceState();
}

class _CatagoryOfServiceState extends State<CatagoryOfService>
    with TickerProviderStateMixin {
  final TextEditingController _controller = TextEditingController();
  final String _typewriterText = "Search what you need...";
  String _displayedText = "";
  int _currentIndex = 0;

  @override
  void initState() {
    super.initState();
    _startTypewriterEffect();
  }

  void _startTypewriterEffect() {
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_currentIndex < _typewriterText.length) {
        setState(() {
          _displayedText += _typewriterText[_currentIndex];
          _currentIndex++;
        });
        _startTypewriterEffect();
      } else {
        Future.delayed(const Duration(seconds: 1), () {
          setState(() {
            _displayedText = "";
            _currentIndex = 0;
          });
          _startTypewriterEffect();
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor:
          Colors.transparent, // Make scaffold background transparent
      appBar: AppBar(
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFF2AD2EF), Color(0xFFB9D9F0)],
            ),
          ),
        ),
      ),
      body: Stack(
        children: [
          Positioned.fill(
            child: Image.asset(
              'assets/bg.jpg', // Replace with your actual image path
              fit: BoxFit.cover,
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 15),
                _searchMenu(),
                const SizedBox(height: 20),
                const Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'All Categories',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                _iconMenu(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _searchMenu() {
    return TextField(
      controller: _controller,
      decoration: InputDecoration(
        focusColor: Colors.transparent,
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: const BorderSide(color: Colors.transparent),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: const BorderSide(color: Colors.transparent),
        ),
        hintText: _displayedText,
        filled: true,
        fillColor: Colors.white,
        hoverColor: Colors.grey[200],
        suffixIcon: Padding(
          padding: const EdgeInsets.only(right: 5.0),
          child: Container(
            decoration: BoxDecoration(
              color: Colors.blue,
              borderRadius: BorderRadius.circular(50),
            ),
            child: IconButton(
              onPressed: () {},
              icon: const Icon(Icons.search),
            ),
          ),
        ),
      ),
    );
  }

  Widget _iconMenu() {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(5),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.4),
          border: Border.all(color: Colors.white),
          borderRadius: BorderRadius.circular(10),
        ),
        child: GridView.count(
          crossAxisCount: 3,
          crossAxisSpacing: 10,
          mainAxisSpacing: 10,
          children: const [
            CategoryItem(
              imagePath: 'assets/logo/air-conditioner.png',
              label: 'AC Repair',
              color: Colors.orange,
              route: '/acRepair',
            ),
            CategoryItem(
              imagePath: 'assets/logo/hair-dryer.png',
              label: 'Beauty',
              color: Colors.purple,
              route: '/beauty',
            ),
            CategoryItem(
              imagePath: 'assets/logo/household-appliance.png',
              label: 'Appliance',
              color: Colors.blue,
              route: '/appliance',
            ),
            CategoryItem(
              imagePath: 'assets/logo/paint-roller.png',
              label: 'Painting',
              color: Colors.green,
              route: '/painting',
            ),
            CategoryItem(
              imagePath: 'assets/logo/cleaning.png',
              label: 'Cleaning',
              color: Colors.yellow,
              route: '/cleaning',
            ),
            CategoryItem(
              imagePath: 'assets/logo/plumbing.png',
              label: 'Plumbing',
              color: Colors.lightGreen,
              route: '/plumbing',
            ),
            CategoryItem(
              imagePath: 'assets/logo/power-plug.png',
              label: 'Electronics',
              color: Colors.red,
              route: '/electronics',
            ),
            CategoryItem(
              imagePath: 'assets/logo/van.png',
              label: 'Shifting',
              color: Colors.pink,
              route: '/shifting',
            ),
            CategoryItem(
              imagePath: 'assets/logo/scissor-and-comb.png',
              label: 'Men\'s Salon',
              color: Colors.lightBlue,
              route: '/mensSalon',
            ),
          ],
        ),
      ),
    );
  }
}

class CategoryItem extends StatefulWidget {
  final String imagePath;
  final String label;
  final Color color;
  final String route;

  const CategoryItem({
    Key? key,
    required this.imagePath,
    required this.label,
    required this.color,
    required this.route,
  }) : super(key: key);

  @override
  _CategoryItemState createState() => _CategoryItemState();
}

class _CategoryItemState extends State<CategoryItem>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    )..repeat();

    // Start the animation immediately when the widget is created
    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        CircleAvatar(
          radius: 30,
          backgroundColor: widget.color.withOpacity(0.2),
          child: RotationTransition(
            turns: _controller,
            child: IconButton(
              icon: Image.asset(widget.imagePath, height: 30, width: 30),
              onPressed: () {
                Navigator.pushNamed(context, widget.route);
              },
            ),
          ),
        ),
        const SizedBox(height: 10),
        Text(
          widget.label,
          style: TextStyle(color: widget.color, fontWeight: FontWeight.bold),
        ),
      ],
    );
  }
}
