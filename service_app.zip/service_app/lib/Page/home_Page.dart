import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:service_app/Page/booking_page.dart';
import 'package:service_app/Page/customerCare_page.dart';
import 'package:service_app/Page/notification_page.dart';
import 'package:service_app/widgets/bottomNavigationBar.dart';
import 'package:service_app/widgets/drawer.dart';
import 'catagoryOfService.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int activeIndex = 0;

  final urlImages = [
    'assets/offer.png',
    'assets/offer.png',
    'assets/offer.png',
    'assets/offer.png',
    ];

  final TextEditingController _controller = TextEditingController();
  final String _typewriterText = "Search what you need...";
  String _displayedText = "";
  int _currentIndex = 0;
  int _selectedIndex = 0;

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  void initState() {
    super.initState();
    _startTypewriterEffect();
  }

  void _startTypewriterEffect() {
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_currentIndex < _typewriterText.length) {
        setState(() {
          _displayedText += _typewriterText[_currentIndex];
          _currentIndex++;
        });
        _startTypewriterEffect();
      } else {
        Future.delayed(const Duration(seconds: 1), () {
          setState(() {
            _displayedText = "";
            _currentIndex = 0;
          });
          _startTypewriterEffect();
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Image.asset(
            'assets/bg.jpg',
            fit: BoxFit.cover,
            height: double.infinity,
            width: double.infinity,
          ),
          SingleChildScrollView(
            child: Center(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  _searchBar(),
                  // const SizedBox(height: 5),
                  _imageSlider(),
                  // const SizedBox(height: 5),
                  _serviceCategories(),
                ],
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: NavigationBars(),
    );
  }

  Widget _searchBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      child: Container(
        height: 200,
        width: 400,
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text("Hello User", style: TextStyle(color: Colors.white)),
              const SizedBox(height: 5),
              RichText(
                text: const TextSpan(
                  text: 'What you Are ',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 30,
                    fontWeight: FontWeight.bold,
                  ),
                  children: <TextSpan>[
                    TextSpan(
                      text: "\nLooking For Today",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 30,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 5),
              TextField(
                controller: _controller,
                decoration: InputDecoration(
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                    borderSide: const BorderSide(color: Colors.transparent),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                    borderSide: const BorderSide(color: Colors.transparent),
                  ),
                  hintText: _displayedText,
                  filled: true,
                  fillColor: Colors.white,
                  suffixIcon: Padding(
                    padding: const EdgeInsets.only(right: 5.0),
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.blue,
                        borderRadius: BorderRadius.circular(50),
                      ),
                      child: IconButton(
                        onPressed: () {},
                        icon: const Icon(Icons.search),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _imageSlider() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Container(
        child: CarouselSlider.builder(
          itemCount: urlImages.length,
          itemBuilder: (context, index, realIndex) {
            final urlImage = urlImages[index];
            return buildImage(urlImage, index);
          },
          options: CarouselOptions(
            autoPlay: true,
            onPageChanged: (index, reason) =>
                setState(() => activeIndex = index),
          ),
        ),
      ),
    );
  }

  Widget buildImage(String urlImage, int index) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 5),
      child: Image.asset(urlImage),
    );
  }

  Widget _serviceCategories() => Padding(
        padding: const EdgeInsets.all(16.0),
        child: SizedBox(
          child: Container(
            decoration: BoxDecoration(
              border: Border.all(color: Colors.white),
              borderRadius: BorderRadius.circular(25),
              color: Colors.white.withOpacity(0.4),
            ),
            child: Column(
              children: [
                const SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    CategoryItem(
                      imagePath: 'assets/logo/air-conditioner.png',
                      label: 'AC Repair',
                      color: Colors.orange,
                      route: '/acRepair',
                    ),
                    CategoryItem(
                      imagePath: 'assets/logo/hair-dryer.png',
                      label: 'Beauty',
                      color: Colors.purple,
                      route: '/beauty',
                    ),
                    CategoryItem(
                      imagePath: 'assets/logo/household-appliance.png',
                      label: 'Appliance',
                      color: Colors.blue,
                      route: '/appliance',
                    ),
                    ServiceCategory(
                      icon: Icons.arrow_forward,
                      color: Colors.grey,
                      label: 'See All',
                      route: '/seeAll',
                    ),
                  ],
                ),
                const SizedBox(height: 10),
              ],
            ),
          ),
        ),
      );
}

class ServiceCategory extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String label;
  final String route;

  const ServiceCategory({
    required this.icon,
    required this.color,
    required this.label,
    required this.route,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        CircleAvatar(
          radius: 30,
          backgroundColor: color,
          child: IconButton(
            icon: Icon(icon, size: 30, color: Colors.black),
            onPressed: () {
              Navigator.pushNamed(context, route);
            },
          ),
        ),
        const SizedBox(height: 8),
        Text(
          label,
          style: const TextStyle(
              fontSize: 14, color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ],
    );
  }
}

class CategoryItem extends StatelessWidget {
  final String imagePath;
  final String label;
  final Color color;
  final String route;

  const CategoryItem({
    required this.imagePath,
    required this.label,
    required this.color,
    required this.route,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        CircleAvatar(
          radius: 30,
          backgroundColor: color.withOpacity(0.2),
          child: IconButton(
            icon: Image.asset(imagePath, height: 30, width: 30),
            onPressed: () {
              Navigator.pushNamed(context, route);
            },
          ),
        ),
        const SizedBox(height: 8),
        Text(
          label,
          style: TextStyle(
              fontSize: 14, color: color, fontWeight: FontWeight.bold),
        ),
      ],
    );
  }
}
