import 'package:flutter/material.dart';
import 'package:service_app/widgets/drawer.dart';

import '../widgets/bottomNavigationBar.dart';
import 'booking_page.dart';
import 'customerCare_page.dart';
import 'home_Page.dart';

class NotificationPage extends StatefulWidget {
  const NotificationPage({super.key});

  @override
  State<NotificationPage> createState() => _NotificationPageState();
}

class _NotificationPageState extends State<NotificationPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        automaticallyImplyLeading: false,
        title: Text(
          "Notification",
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFF2AD2EF), Color(0xFFB9D9F0)],
            ),
          ),
        ),
      ),
      bottomNavigationBar: NavigationBars(),
      body: NotificationsPage(),
    );
  }
}

class NotificationsPage extends StatefulWidget {
  @override
  _NotificationsPageState createState() => _NotificationsPageState();
}

class _NotificationsPageState extends State<NotificationsPage> {
  final GlobalKey<AnimatedListState> _listKey = GlobalKey<AnimatedListState>();
  final List<NotificationItem> _notifications = [];

  @override
  void initState() {
    super.initState();
    // Add initial items to the list with a delay to create a slide-in effect on page load
    Future.delayed(Duration(milliseconds: 500), () {
      for (int i = 0; i < initialNotifications.length; i++) {
        Future.delayed(Duration(milliseconds: i * 300), () {
          _addItem(initialNotifications[i]);
        });
      }
    });
  }

  void _addItem(NotificationItem item) {
    final int index = _notifications.length;
    _notifications.add(item);
    _listKey.currentState?.insertItem(index);
  }

  Widget _buildItem(NotificationItem item, Animation<double> animation) {
    return SlideTransition(
      position: Tween<Offset>(
        begin: const Offset(1, 0),
        end: Offset.zero,
      ).animate(animation),
      child: NotificationCard(notification: item),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Stack(
        children: [
          // Background image
          Positioned.fill(
            child: Image.asset(
              'assets/bg.jpg', // Update with your image path
              fit: BoxFit.cover,
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: Colors.white.withOpacity(0.4),
              ),
              child: AnimatedList(
                key: _listKey,
                initialItemCount: _notifications.length,
                itemBuilder: (context, index, animation) {
                  return _buildItem(_notifications[index], animation);
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  final List<NotificationItem> initialNotifications = [
    NotificationItem(
      title: 'AC Installation (Both) service payment is successfully Paid.',
      subtitle: '5:44 PM',
      icon: Icons.payment,
      color: Colors.orangeAccent,
    ),
    NotificationItem(
      title: 'Booking Status has been changed 3:00-4:00 PM',
      subtitle: 'Friday, Jun 21 at 5:44 PM',
      icon: Icons.calendar_today,
      color: Colors.purpleAccent,
    ),
    NotificationItem(
      title: 'Confirmed Your booking AC Installation',
      subtitle: 'Thursday, Jun 20 at 5:44 PM',
      icon: Icons.check_circle,
      color: Colors.green,
    ),
    NotificationItem(
      title: 'Hair Style Professional Coming today 2:00-3:00 PM',
      subtitle: 'Sunday, Jun 16 at 5:44 PM',
      icon: Icons.event,
      color: Colors.yellow,
    ),
    NotificationItem(
      title: 'Order Cancelled! Home Deep Cleaning Westinghouse.',
      subtitle: 'Jun 7, 2024 at 5:44 PM',
      icon: Icons.cancel,
      color: Colors.red,
    ),
  ];
}

class NotificationItem {
  final String title;
  final String subtitle;
  final IconData icon;
  final Color color;

  NotificationItem({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.color,
  });
}

class NotificationCard extends StatelessWidget {
  final NotificationItem notification;

  NotificationCard({required this.notification});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 5.0),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 25,
                  backgroundColor: notification.color,
                  child: Icon(
                    notification.icon,
                    size: 30,
                    color: Colors.white,
                  ),
                ),
                SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        notification.title,
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(height: 4),
                      Text(
                        notification.subtitle,
                        style: TextStyle(
                          color: Colors.grey,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Divider()
        ],
      ),
    );
  }
}
