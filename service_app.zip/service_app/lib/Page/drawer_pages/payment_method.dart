import 'package:flutter/material.dart';
import 'package:service_app/Page/drawer_pages/addCard_Page.dart';

class PaymentMethod extends StatefulWidget {
  const PaymentMethod({super.key});

  @override
  State<PaymentMethod> createState() => _PaymentMethodState();
}

class _PaymentMethodState extends State<PaymentMethod> {
  @override
  Widget build(BuildContext context) {
    return CardListScreen();
  }
}

class CardListScreen extends StatefulWidget {
  @override
  State<CardListScreen> createState() => _CardListScreenState();
}

class _CardListScreenState extends State<CardListScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Card List',
          style: TextStyle(color: Colors.white),
        ),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Color(0xFFFD2662), Color(0xFFFE0523)],
            ),
          ),
        ),
      ),
      body: Stack(
        children: [
          // Background image
          Positioned.fill(
            child: Image.asset(
              'assets/bg.jpg',
              fit: BoxFit.cover,
            ),
          ),
          // Foreground content
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: [
                CardListSection(),
                SizedBox(height: 16),
                CreditSection(),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class CardListSection extends StatefulWidget {
  @override
  _CardListSectionState createState() => _CardListSectionState();
}

class _CardListSectionState extends State<CardListSection> {
  int selectedCardIndex = -1;

  final List<CardInfo> cardList = [
    CardInfo(
      type: 'MasterCard',
      maskedNumber: '************5321',
      expirationDate: '04/2023',
      logo: 'assets/money.png',
    ),
    CardInfo(
      type: 'Visa',
      maskedNumber: '************3426',
      expirationDate: '04/2023',
      logo: 'assets/card.png',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          color: Colors.white
              .withOpacity(0.4), // Add some opacity to the background
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: Colors.white)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Add Card List',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                TextButton(
                  onPressed: () {
                    showDialog(
                      context: context,
                      builder: (BuildContext context) {
                        return AlertDialog(
                          title: Text('Add New Card'),
                          content: SingleChildScrollView(
                            child: AddNewCardForm(),
                          ),
                          actions: <Widget>[
                            TextButton(
                              child: Text('Cancel'),
                              onPressed: () {
                                Navigator.of(context).pop();
                              },
                            ),
                          ],
                        );
                      },
                    );
                  },
                  child: Text(
                    'Add New',
                    style: TextStyle(color: Colors.blue),
                  ),
                ),
              ],
            ),
            ListView.separated(
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              itemCount: cardList.length,
              itemBuilder: (context, index) {
                return CardItem(
                  cardInfo: cardList[index],
                  isSelected: selectedCardIndex == index,
                  onTap: () {
                    setState(() {
                      selectedCardIndex = index;
                    });
                  },
                );
              },
              separatorBuilder: (context, index) => Divider(),
            ),
          ],
        ),
      ),
    );
  }
}

class CardItem extends StatelessWidget {
  final CardInfo cardInfo;
  final bool isSelected;
  final VoidCallback onTap;

  CardItem({
    required this.cardInfo,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Image.asset(cardInfo.logo, width: 40),
      title: Text(cardInfo.maskedNumber),
      subtitle: Text('Exp ${cardInfo.expirationDate}'),
      trailing: isSelected
          ? Icon(Icons.radio_button_checked, color: Colors.blue)
          : Icon(Icons.radio_button_unchecked),
      onTap: onTap,
    );
  }
}

class CreditSection extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          color: Colors.white
              .withOpacity(0.4), // Add some opacity to the background
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: Colors.white)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Your Credit',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 8),
            ListTile(
              leading: Container(
                padding: const EdgeInsets.all(8.0),
                decoration: BoxDecoration(
                  color: Colors.purple.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(
                  Icons.wallet,
                  color: Colors.purple,
                ),
              ),
              title: Text(
                'USD 500',
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.orange,
                  fontWeight: FontWeight.bold,
                ),
              ),
              subtitle: Text('Exp 04/2023'),
              trailing: TextButton.icon(
                onPressed: () {
                  // Apply logic
                },
                icon: Icon(Icons.edit, size: 16, color: Colors.blue),
                label: Text(
                  'Apply',
                  style: TextStyle(color: Colors.blue),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class CardInfo {
  final String type;
  final String maskedNumber;
  final String expirationDate;
  final String logo;

  CardInfo({
    required this.type,
    required this.maskedNumber,
    required this.expirationDate,
    required this.logo,
  });
}
