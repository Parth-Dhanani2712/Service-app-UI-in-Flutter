import 'package:flutter/material.dart';

class AddressListScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Address List'),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFF2AD2EF), Color(0xFFB9D9F0)],
            ),
          ),
        ),
      ),
      body: Stack(
        children: [
          Positioned.fill(
            child: Image.asset(
              'assets/bg.jpg', // Path to your background image
              fit: BoxFit.cover,
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: AddressList(),
          ),
        ],
      ),
    );
  }
}

class AddressList extends StatelessWidget {
  final List<AddressInfo> addresses = [
    AddressInfo(
      type: 'Office',
      icon: Icons.business,
      iconColor: Colors.purple,
      address: '55 North Frontage Rd, Jackson, MS 39211, US',
    ),
    AddressInfo(
      type: 'Home',
      icon: Icons.home,
      iconColor: Colors.orange,
      address: '55 North Frontage Rd, Jackson, MS 39211, US',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      itemCount: addresses.length,
      separatorBuilder: (context, index) => SizedBox(height: 16),
      itemBuilder: (context, index) {
        return AddressItem(
          addressInfo: addresses[index],
        );
      },
    );
  }
}

class AddressItem extends StatelessWidget {
  final AddressInfo addressInfo;

  AddressItem({required this.addressInfo});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(16.0),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.white),
        borderRadius: BorderRadius.circular(25),
        color: Colors.white.withOpacity(0.4),
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 24,
            backgroundColor: addressInfo.iconColor.withOpacity(0.2),
            child: Icon(
              addressInfo.icon,
              color: addressInfo.iconColor,
              size: 30,
            ),
          ),
          SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  addressInfo.type,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  addressInfo.address,
                  style: TextStyle(
                    color: Colors.grey[700],
                    fontSize: 14,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class AddressInfo {
  final String type;
  final IconData icon;
  final Color iconColor;
  final String address;

  AddressInfo({
    required this.type,
    required this.icon,
    required this.iconColor,
    required this.address,
  });
}
