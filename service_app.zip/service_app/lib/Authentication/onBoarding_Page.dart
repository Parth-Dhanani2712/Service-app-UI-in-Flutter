import 'dart:async';
import 'package:flutter/material.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';
import '../widgets/drawer.dart';
import 'signIn.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  _OnboardingScreenState createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final PageController _pageController = PageController(initialPage: 0);
  int _currentPage = 0;
  late Timer _timer;

  @override
  void initState() {
    super.initState();
    _startAutoPageTransition();
  }

  @override
  void dispose() {
    _pageController.dispose();
    _timer.cancel();
    super.dispose();
  }

  void _startAutoPageTransition() {
    _timer = Timer.periodic(Duration(seconds: 3), (Timer timer) {
      if (_currentPage < 3) {
        setState(() {
          _currentPage++;
        });
      } else {
        setState(() {
          _currentPage = 0;
        });
      }

      _pageController.animateToPage(
        _currentPage,
        duration: Duration(milliseconds: 400),
        curve: Curves.easeInOut,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Use Expanded to give PageView proper constraints within a Column
          Column(
            children: [
              Expanded(
                child: PageView(
                  controller: _pageController,
                  children: [
                    OnboardingPage(
                      image: 'assets/onboarding/beauty.png',
                      title: 'Beauty parlour at your home',
                      description:
                          'Lorem ipsum is a placeholder text commonly used to demonstrate the visual.',
                    ),
                    OnboardingPage(
                      image: 'assets/onboarding/plumbing.jpg',
                      title: 'Plumber & expert nearby you',
                      description:
                          'Lorem ipsum is a placeholder text commonly used to demonstrate the visual.',
                    ),
                    OnboardingPage(
                      image: 'assets/onboarding/electrician.jpg',
                      title: 'Electrician services',
                      description:
                          'Lorem ipsum is a placeholder text commonly used to demonstrate the visual.',
                    ),
                    OnboardingPage(
                      image: 'assets/onboarding/cleaning.jpg',
                      title: 'Professional home cleaning',
                      description:
                          'Lorem ipsum is a placeholder text commonly used to demonstrate the visual.',
                    ),
                  ],
                ),
              ),
            ],
          ),
          Positioned(
            top: 50,
            right: 20,
            child: TextButton(
              onPressed: () {
                // Skip button action
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => LoginScreen()),
                );
              },
              child: Text(
                'Skip',
                style: TextStyle(color: Colors.green),
              ),
            ),
          ),
          Positioned(
            bottom: 20,
            left: 20,
            right: 20,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                SmoothPageIndicator(
                  controller: _pageController,
                  count: 4, // Update the count to match the number of pages
                  effect: ExpandingDotsEffect(
                    activeDotColor: Colors.pink,
                    dotColor: Colors.grey,
                    dotHeight: 10,
                    dotWidth: 10,
                    expansionFactor: 2,
                  ),
                ),
                Container(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [Color(0xFFFF646C), Color(0xFFFD2662)],
                    ),
                  ),
                  child: ElevatedButton(
                    onPressed: () {
                      // Move to the next page or finish
                      if (_currentPage < 3) {
                        setState(() {
                          _currentPage++;
                        });
                      } else {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(builder: (context) => LoginScreen()),
                        );
                      }
                      _pageController.animateToPage(
                        _currentPage,
                        duration: Duration(milliseconds: 400),
                        curve: Curves.easeInOut,
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      shape: CircleBorder(),
                      padding: EdgeInsets.all(16),
                      backgroundColor: Colors.transparent, // Set transparent to see the gradient
                    ),
                    child: Icon(Icons.arrow_forward, color: Colors.white),
                  ),
                ),

              ],
            ),
          ),
        ],
      ),
    );
  }
}

class OnboardingPage extends StatelessWidget {
  final String image;
  final String title;
  final String description;

  OnboardingPage({
    required this.image,
    required this.title,
    required this.description,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(20.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Expanded(
            flex: 2,
            child: Image.asset(image),
          ),
          Text(
            title,
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
            textAlign: TextAlign.center,
          ),
          Text(
            description,
            style: TextStyle(
              fontSize: 16,
              color: Colors.grey,
            ),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 200),
        ],
      ),
    );
  }
}
