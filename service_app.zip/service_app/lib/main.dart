import 'package:flutter/material.dart';
import 'package:service_app/Authentication/onBoarding_Page.dart';
import 'package:service_app/Authentication/signIn.dart';
import 'package:service_app/Page/customerCare_page.dart';
import 'package:service_app/Page/drawer_pages/calender_Page.dart';
import 'package:service_app/Page/drawer_pages/payment_method.dart';
import 'package:service_app/Page/notification_page.dart';

import 'package:service_app/widgets/drawer.dart';

import 'Page/Feature Page/acRepair.dart';
import 'Page/Feature Page/appliencePage.dart';
import 'Page/Feature Page/beautyPage.dart';
import 'Page/Feature Page/cleaningPage.dart';
import 'Page/Feature Page/electronicsPage.dart';
import 'Page/Feature Page/mensSalonPage.dart';
import 'Page/Feature Page/paintingPage.dart';
import 'Page/Feature Page/plumbingPage.dart';
import 'Page/Feature Page/shiftingPage.dart';
import 'Page/catagoryOfService.dart';
import 'Page/drawer_pages/address_Page.dart';

void main() {
  runApp(
    MaterialApp(
      home: OnboardingScreen(),
      debugShowCheckedModeBanner: false,
      routes: {
        '/acRepair': (context) => AcRepairPage(),
        '/beauty': (context) => BeautyPage(),
        '/appliance': (context) => AppliancePage(),
        '/seeAll': (context) => CatagoryOfService(),
        '/painting': (context) => PaintingPage(),
        '/cleaning': (context) => CleaningPage(),
        '/plumbing': (context) => PlumbingPage(),
        '/electronics': (context) => ElectronicsPage(),
        '/shifting': (context) => ShiftingPage(),
        '/mensSalon': (context) => MensSalonPage(),
        '/notification': (context) => NotificationPage(),
        '/customercare': (context) => CustomercarePage(),
        '/payment': (context) => PaymentMethod(),
        '/address': (context) => AddressListScreen(),
        '/calender': (context) => CalendarPage(),
        '/logout': (context) => LoginScreen(),
      },
    ),
  );
}

