import 'package:flutter/material.dart';
import 'package:service_app/Page/home_Page.dart';

import '../Page/drawer_pages/profile_Page.dart';

class navDrawer extends StatefulWidget {
  const navDrawer({super.key});

  @override
  State<navDrawer> createState() => _navDrawerState();
}

class _navDrawerState extends State<navDrawer> {
  final List<Map<String, dynamic>> items = [
    {
      'title': 'Calender',
      'icon': Icons.calendar_month,
      'route': '/calender',
    },
    {
      'title': 'Payment Method',
      'icon': Icons.wallet_outlined,
      'route': '/payment'
    },
    {
      'title': 'Address',
      'icon': Icons.add_location_alt_outlined,
      'route': '/address'
    },
    {
      'title': 'Notification',
      'icon': Icons.notifications_outlined,
      'route': '/notification'
    },
    {
      'title': 'Offer',
      'icon': Icons.local_offer_outlined,
      'route': '/offer',
    },
    {
      'title': 'Refer A Friend',
      'icon': Icons.person,
      'route': '/profile',
    },
    {
      'title': 'Support',
      'icon': Icons.phone_outlined,
      'route': '/customercare',
    },
    {
      'title': 'Rate Us',
      'icon': Icons.star_border_outlined,
      'route': '/rate',
    },
    {
      'title': 'Log Out',
      'icon': Icons.logout_outlined,
      'route': '/logout',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          "Service App",
          style: TextStyle(color: Colors.white),
        ),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFF2AD2EF), Color(0xFFB9D9F0)],
            ),
          ),
        ),
        backgroundColor: Colors.white,
        leading: Builder(
          builder: (context) {
            return IconButton(
              icon: const Icon(
                Icons.menu,
                color: Colors.white,
              ),
              onPressed: () {
                Scaffold.of(context).openDrawer();
              },
            );
          },
        ),
      ),
      drawer: Drawer(
        child: ListView(
          // Important: Remove any padding from the ListView.
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Color(0xFF2AD2EF), Color(0xFFB9D9F0)],
                  begin: Alignment.topLeft,
                  end: Alignment.topRight,
                  stops: [0.0, 0.8],
                  tileMode: TileMode.clamp,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  CircleAvatar(
                    child: IconButton(
                        onPressed: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => ProfilePage()));
                        },
                        icon: Icon(Icons.person)),
                  ),
                  SizedBox(width: 3),
                  Text(
                    'John Deo',
                    style: TextStyle(color: Colors.white, fontSize: 20),
                  ),
                  Text("johndeo@gmail.com"),
                ],
              ),
            ),
            ...items.map((item) {
              return Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Color(0xFFFF646C), Color(0xFFFD2662)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    stops: [0.0, 0.5],
                    tileMode: TileMode.clamp,
                  ),
                ),
                child: Column(
                  children: [
                    ListTile(
                      leading: Icon(
                        item['icon'],
                        color: Colors.white,
                      ),
                      title: Text(
                        item['title'],
                        style: TextStyle(color: Colors.white),
                      ),
                      onTap: () {
                        Navigator.pushNamed(context, item['route']);
                        print('Tapped on ${item['title']}');
                      },
                    ),
                    //SizedBox(height: 20),
                    Divider(),
                  ],
                ),
              );
            }).toList(),
          ],
        ),
      ),
      body: HomePage(),
    );
  }
}
